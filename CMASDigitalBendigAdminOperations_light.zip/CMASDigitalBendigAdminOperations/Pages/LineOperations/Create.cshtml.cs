using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using CMASDigitalBendigAdminOperations.Services;

namespace CMASDigitalBendigAdminOperations.Pages.LineOperations
{
    /// <summary>
    /// Creates a new Line Operation record (Line, Operation_Id, TagName, TagValue,
    /// Employee_ID, Date_Inserted). Requires a database connection already picked
    /// on Page 1. Date_Inserted is set automatically to the current time.
    /// </summary>
    public class CreateModel : PageModel
    {
        private readonly IDatabaseConnectionService _dbConnectionService;
        private readonly ISystemDataService _systemDataService;
        private readonly ISessionConnectionAccessor _sessionAccessor;
        private readonly ILogger<CreateModel> _logger;

        public CreateModel(
            IDatabaseConnectionService dbConnectionService,
            ISystemDataService systemDataService,
            ISessionConnectionAccessor sessionAccessor,
            ILogger<CreateModel> logger)
        {
            _dbConnectionService = dbConnectionService;
            _systemDataService = systemDataService;
            _sessionAccessor = sessionAccessor;
            _logger = logger;
        }

        [BindProperty]
        [Required(ErrorMessage = "Please select a line.")]
        public string Line { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Operation Id is required.")]
        [StringLength(50)]
        public string OperationId { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Tag name is required.")]
        [StringLength(150)]
        public string TagName { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Tag value is required.")]
        [StringLength(250)]
        public string TagValue { get; set; } = string.Empty;

        [BindProperty]
        [StringLength(50)]
        public string? EmployeeId { get; set; }

        public List<SelectListItem> LineOptions { get; set; } = new();
        public List<SelectListItem> TagNameOptions { get; } = TagNames.Select(t => new SelectListItem(t, t)).ToList();
        public string? SelectedDbDisplayName { get; set; }
        public string? ErrorMessage { get; set; }

        [TempData]
        public string? StatusMessage { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var guard = EnsureConnection();
            if (guard != null) return guard;

            await LoadLineOptionsAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var guard = EnsureConnection();
            if (guard != null) return guard;

            if (!ModelState.IsValid)
            {
                await LoadLineOptionsAsync();
                return Page();
            }

            try
            {
                var connectionKey = _sessionAccessor.GetSelectedConnectionKey()!;
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);

                var record = new Dictionary<string, object?>
                {
                    ["Line"] = Line,
                    ["Operation_Id"] = OperationId,
                    ["TagName"] = TagName,
                    ["TagValue"] = TagValue,
                    ["Employee_ID"] = string.IsNullOrWhiteSpace(EmployeeId) ? "0" : EmployeeId,
                    ["Date_Inserted"] = DateTime.Now.ToString("g")
                };

                await _systemDataService.CreateRecordAsync(connectionString, record);

                StatusMessage = $"Line operation '{TagName}' was created for {Line}.";
                return RedirectToPage();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Failed to create line operation record.");
                ErrorMessage = ex.Message;
                await LoadLineOptionsAsync();
                return Page();
            }
        }

        private IActionResult? EnsureConnection()
        {
            var connectionKey = _sessionAccessor.GetSelectedConnectionKey();
            if (string.IsNullOrEmpty(connectionKey))
            {
                return RedirectToPage("/Index");
            }

            SelectedDbDisplayName = _dbConnectionService.FindByKey(connectionKey)?.DisplayName;
            return null;
        }

        private async Task LoadLineOptionsAsync()
        {
            try
            {
                var connectionKey = _sessionAccessor.GetSelectedConnectionKey()!;
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);
                var lines = await _systemDataService.GetSystemNamesAsync(connectionString);
                LineOptions = lines.Select(l => new SelectListItem(l, l)).ToList();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Failed to load lines for the dropdown.");
                ErrorMessage ??= ex.Message;
            }
        }

        // Known Tag Names for the searchable Tag Name dropdown. In a real deployment
        // this would likely be sourced from the vision/PLC system's own tag catalog
        // rather than hardcoded here.
        private static readonly List<string> TagNames = new()
        {
            "ActualLieCell", "ActualLoftCell", "CalibrationCHsRowIndex", "CalibrationClubCell",
            "CalibrationClubCellRowIndex", "CalibrationClubIsLeftHand", "CalibrationModeCell",
            "CameraCorrectedLie", "CameraCorrectedLoft", "CPUType", "CurrentLiePositionCell",
            "CurrentLoftPositionCell", "CylinderExtendCell1", "DigitalBenderNumber",
            "FaceBackClampCell", "FaceBackClampEngageCell", "FaceCorrectionValueCell",
            "FaceInsightIpAddress", "FaceMainClampCell", "FaceMainClampEngageCell",
            "FromTraceability", "GlobalDirectory", "IndexToPositionCell", "InitialConnection",
            "InitialConnectionLoft", "IsUKMachine", "LeftHandCalibrationCell",
            "LHLIE_Forged 3", "LHLIE_Forged 4", "LHLIE_Forged 5", "LHLIE_Forged 6",
            "LHLIE_Forged 7", "LHLIE_Forged 8", "LHLIE_Forged 9", "LHLIE_Forged AW",
            "LHLIE_Forged PW", "LHLIE_MD5 58",
            "LHLOFT_Forged 3", "LHLOFT_Forged 4", "LHLOFT_Forged 5", "LHLOFT_Forged 6",
            "LHLOFT_Forged 7", "LHLOFT_Forged 8", "LHLOFT_Forged 9", "LHLOFT_Forged AW",
            "LHLOFT_Forged PW", "LHLOFT_MD5 58",
            "LieCamPositionCell", "LieLofttoleranceangle", "LieShaftPosition",
            "LightsExtendCell", "LocalSaveDataDirectory", "LocalSaveDataFilename",
            "LocalSaveDataFilenameBackup", "LoftCamPositionCell", "LoftLeftHandCalibrationCell",
            "LoftShaftPositionCell", "OscillationCell",
            "plcBackClampTag", "PlcBackClampTagName", "plcBacklightsTag", "PlcBacklightsTagName",
            "PlcIpAddress", "plcMainClampTag", "PlcMainClampTagName", "plcSaveTag", "PlcSaveTagName",
            "RawLieCellRowIndex", "RawLoftCellRowIndex",
            "RHLIE_Forged 3", "RHLIE_Forged 4", "RHLIE_Forged 5", "RHLIE_Forged 6",
            "RHLIE_Forged 7", "RHLIE_Forged 8", "RHLIE_Forged 9", "RHLIE_Forged AW",
            "RHLIE_Forged PW", "RHLIE_MD5 58",
            "RHLOFT_Forged 3", "RHLOFT_Forged 4", "RHLOFT_Forged 5", "RHLOFT_Forged 6",
            "RHLOFT_Forged 7", "RHLOFT_Forged 8", "RHLOFT_Forged 9", "RHLOFT_Forged AW",
            "RHLOFT_Forged PW", "RHLOFT_MD5 58",
            "SaveClubHeadCell", "SaveDataCell", "SaveProductModelCell", "SaveTimestampCell",
            "SMTPHost", "TargetLieCell", "TargetLoftCell", "TeachCell",
            "toleranceLie", "toleranceLoft"
        };
    }
}
