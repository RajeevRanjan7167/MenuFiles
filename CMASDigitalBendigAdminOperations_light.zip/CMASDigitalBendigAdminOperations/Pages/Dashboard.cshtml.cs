using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CMASDigitalBendigAdminOperations.Services;

namespace CMASDigitalBendigAdminOperations.Pages
{
    /// <summary>
    /// Landing page shown right after a database connection is chosen on Page 1.
    /// Requires a connection to already be selected in session, same guard pattern
    /// used by SystemConfig - if missing, send the user back to pick one.
    /// </summary>
    public class DashboardModel : PageModel
    {
        private readonly IDatabaseConnectionService _dbConnectionService;
        private readonly ISystemDataService _systemDataService;
        private readonly ISessionConnectionAccessor _sessionAccessor;
        private readonly ILogger<DashboardModel> _logger;

        public DashboardModel(
            IDatabaseConnectionService dbConnectionService,
            ISystemDataService systemDataService,
            ISessionConnectionAccessor sessionAccessor,
            ILogger<DashboardModel> logger)
        {
            _dbConnectionService = dbConnectionService;
            _systemDataService = systemDataService;
            _sessionAccessor = sessionAccessor;
            _logger = logger;
        }

        public string? SelectedDbDisplayName { get; set; }
        public int LineCount { get; set; }
        public int RecordCount { get; set; }
        public string? ErrorMessage { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var connectionKey = _sessionAccessor.GetSelectedConnectionKey();
            if (string.IsNullOrEmpty(connectionKey))
            {
                return RedirectToPage("/Index");
            }

            var option = _dbConnectionService.FindByKey(connectionKey);
            SelectedDbDisplayName = option?.DisplayName;

            try
            {
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);
                var lines = await _systemDataService.GetSystemNamesAsync(connectionString);
                LineCount = lines.Count;

                var allRecords = await _systemDataService.GetRecordsAsync(connectionString, null);
                RecordCount = allRecords.Rows.Count;
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Failed to load dashboard summary for connection {Key}.", connectionKey);
                ErrorMessage = ex.Message;
            }

            return Page();
        }
    }
}
