using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using CMASDigitalBendigAdminOperations.Models;
using CMASDigitalBendigAdminOperations.Services;

namespace CMASDigitalBendigAdminOperations.Pages.Lines
{
    /// <summary>
    /// Lines management page: shows the Lines table (Line, PcName, Operation_Id,
    /// PercentToTest, LastVersion, Status) and a "Add New Line" button that opens a
    /// modal with the create form. Requires a database connection already picked
    /// on Page 1.
    /// </summary>
    public class CreateModel : PageModel
    {
        private readonly IDatabaseConnectionService _dbConnectionService;
        private readonly ISystemDataService _systemDataService;
        private readonly ISessionConnectionAccessor _sessionAccessor;
        private readonly ILogger<CreateModel> _logger;

        public CreateModel(
            IDatabaseConnectionService dbConnectionService,
            ISystemDataService systemDataService,
            ISessionConnectionAccessor sessionAccessor,
            ILogger<CreateModel> logger)
        {
            _dbConnectionService = dbConnectionService;
            _systemDataService = systemDataService;
            _sessionAccessor = sessionAccessor;
            _logger = logger;
        }

        [BindProperty]
        [Required(ErrorMessage = "Line is required.")]
        [StringLength(100)]
        public string Line { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "PC Name is required.")]
        [StringLength(100)]
        public string PcName { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Operation Id is required.")]
        [StringLength(50)]
        public string OperationId { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Percent to test is required.")]
        [Range(0, 100, ErrorMessage = "Percent to test must be between 0 and 100.")]
        public int PercentToTest { get; set; } = 100;

        [BindProperty]
        [Required(ErrorMessage = "Last version is required.")]
        [StringLength(20)]
        public string LastVersion { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Status is required.")]
        public string Status { get; set; } = string.Empty;

        public GridResult Lines { get; set; } = new();
        public List<SelectListItem> StatusOptions { get; } = new()
        {
            new("Production UK", "Production UK"),
            new("Production MX", "Production MX"),
            new("Virtual", "Virtual"),
            new("Disabled", "Disabled"),
        };

        public string? SelectedDbDisplayName { get; set; }
        public string? ErrorMessage { get; set; }

        [TempData]
        public string? StatusMessage { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var guard = EnsureConnection();
            if (guard != null) return guard;

            await LoadLinesAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var guard = EnsureConnection();
            if (guard != null) return guard;

            if (!ModelState.IsValid)
            {
                await LoadLinesAsync();
                return Page();
            }

            try
            {
                var connectionKey = _sessionAccessor.GetSelectedConnectionKey()!;
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);

                var record = new Dictionary<string, object?>
                {
                    ["Line"] = Line.Trim(),
                    ["PcName"] = PcName.Trim(),
                    ["Operation_Id"] = OperationId.Trim(),
                    ["PercentToTest"] = PercentToTest.ToString(),
                    ["LastVersion"] = LastVersion.Trim(),
                    ["Status"] = Status
                };

                await _systemDataService.CreateLineAsync(connectionString, record);

                StatusMessage = $"Line '{Line}' was created.";
                return RedirectToPage();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Failed to create line '{Line}'.", Line);
                ErrorMessage = ex.Message;
                await LoadLinesAsync();
                return Page();
            }
        }

        private IActionResult? EnsureConnection()
        {
            var connectionKey = _sessionAccessor.GetSelectedConnectionKey();
            if (string.IsNullOrEmpty(connectionKey))
            {
                return RedirectToPage("/Index");
            }

            SelectedDbDisplayName = _dbConnectionService.FindByKey(connectionKey)?.DisplayName;
            return null;
        }

        private async Task LoadLinesAsync()
        {
            try
            {
                var connectionKey = _sessionAccessor.GetSelectedConnectionKey()!;
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);
                Lines = await _systemDataService.GetLinesAsync(connectionString);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Failed to load the Lines table.");
                ErrorMessage ??= ex.Message;
            }
        }
    }
}
