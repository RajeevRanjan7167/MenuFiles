using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using CMASDigitalBendigAdminOperations.Services;

namespace CMASDigitalBendigAdminOperations.Pages
{
    /// <summary>
    /// Page 1: lets the user pick which configured database connection to use for
    /// the rest of their session, validates it can actually be reached, then stores
    /// the choice in session and redirects to Page 2.
    /// </summary>
    public class IndexModel : PageModel
    {
        private readonly IDatabaseConnectionService _dbConnectionService;
        private readonly ISessionConnectionAccessor _sessionAccessor;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(
            IDatabaseConnectionService dbConnectionService,
            ISessionConnectionAccessor sessionAccessor,
            ILogger<IndexModel> logger)
        {
            _dbConnectionService = dbConnectionService;
            _sessionAccessor = sessionAccessor;
            _logger = logger;
        }

        [BindProperty]
        [Required(ErrorMessage = "Please select a database connection.")]
        public string SelectedConnectionKey { get; set; } = string.Empty;

        public List<SelectListItem> ConnectionOptions { get; set; } = new();

        [TempData]
        public string? ErrorMessage { get; set; }

        public void OnGet()
        {
            LoadConnectionOptions();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            LoadConnectionOptions();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                // Confirm the connection is actually reachable before committing
                // to it for the session - avoids a confusing failure on Page 2.
                await _dbConnectionService.ValidateConnectionAsync(SelectedConnectionKey);

                _sessionAccessor.SetSelectedConnectionKey(SelectedConnectionKey);

                return RedirectToPage("/Dashboard");
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Database connection validation failed for key {Key}.", SelectedConnectionKey);
                ErrorMessage = ex.Message;
                return Page();
            }
        }

        private void LoadConnectionOptions()
        {
            ConnectionOptions = _dbConnectionService.GetAvailableConnections()
                .Select(c => new SelectListItem(c.DisplayName, c.Key))
                .ToList();
        }
    }
}
