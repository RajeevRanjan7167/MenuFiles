(function () {
    var sidebar = document.getElementById('appSidebar');
    var toggleBtn = document.getElementById('sidebarToggleBtn');
    if (!sidebar || !toggleBtn) {
        return;
    }

    var mobileQuery = window.matchMedia('(max-width: 991.98px)');

    // Restore the user's last collapsed/expanded preference (desktop only).
    if (!mobileQuery.matches && localStorage.getItem('cmasSidebarCollapsed') === 'true') {
        sidebar.classList.add('collapsed');
    }

    toggleBtn.addEventListener('click', function () {
        if (mobileQuery.matches) {
            // On smaller screens, treat the sidebar as an off-canvas drawer.
            sidebar.classList.toggle('mobile-open');
        } else {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('cmasSidebarCollapsed', sidebar.classList.contains('collapsed'));
        }
    });
})();
