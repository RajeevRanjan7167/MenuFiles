namespace CMASDigitalBendigAdminOperations.Services
{
    internal static class DummyLinesData
    {
        public static List<Dictionary<string, object?>> CreateRows() => new()
        {
            new() { ["Line"] = "CUST1_UK", ["PcName"] = "UK51619", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST10_UK", ["PcName"] = "U55983", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST11_UK", ["PcName"] = "U54220", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST2_UK", ["PcName"] = "UK53509", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST3_UK", ["PcName"] = "UK53510", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST4_UK", ["PcName"] = "UK40080", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST6_UK", ["PcName"] = "UK53589", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST7_UK", ["PcName"] = "U60503", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "CUST9_UK", ["PcName"] = "U53509", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production UK" },
            new() { ["Line"] = "MXCUSTOMS 10A", ["PcName"] = "M53961", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 1A", ["PcName"] = "hjlhjhjlk", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Disabled" },
            new() { ["Line"] = "MXCUSTOMS 5A", ["PcName"] = "MXCUSTOMS 5A", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Virtual" },
            new() { ["Line"] = "MXCUSTOMS 5B", ["PcName"] = "MXCUSTOMS 5B", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Virtual" },
            new() { ["Line"] = "MXCUSTOMS 6A", ["PcName"] = "M50245", ["Operation_Id"] = "54", ["PercentToTest"] = "50", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 6B", ["PcName"] = "M50412", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 7A", ["PcName"] = "M50410", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 7B", ["PcName"] = "M51144", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 8A", ["PcName"] = "M10058", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 8B", ["PcName"] = "M50502", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 9A", ["PcName"] = "M53508", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXCUSTOMS 9B", ["PcName"] = "C51217", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20260607", ["Status"] = "Production MX" },
            new() { ["Line"] = "MXWOODS5", ["PcName"] = "U53589", ["Operation_Id"] = "54", ["PercentToTest"] = "100", ["LastVersion"] = "20251027", ["Status"] = "Production UK" },
        };
    }
}
