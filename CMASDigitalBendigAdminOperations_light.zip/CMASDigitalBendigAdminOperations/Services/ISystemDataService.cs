using CMASDigitalBendigAdminOperations.Models;

namespace CMASDigitalBendigAdminOperations.Services
{
    public interface ISystemDataService
    {
        Task<List<string>> GetSystemNamesAsync(string connectionString);
        Task<GridResult> GetRecordsAsync(string connectionString, string? systemName);
        Task<Dictionary<string, object?>> UpdateRecordAsync(string connectionString, Dictionary<string, object?> record);

        /// <summary>Returns the full Lines table (Line, PcName, Operation_Id, PercentToTest, LastVersion, Status).</summary>
        Task<GridResult> GetLinesAsync(string connectionString);

        /// <summary>Adds a new Line record so it becomes selectable elsewhere in the app.</summary>
        Task<Dictionary<string, object?>> CreateLineAsync(string connectionString, Dictionary<string, object?> record);

        /// <summary>Creates a new Line Operation record (Line, Operation_Id, TagName, TagValue, ...).</summary>
        Task<Dictionary<string, object?>> CreateRecordAsync(string connectionString, Dictionary<string, object?> record);
    }
}
