export const environment = {
  production: true,
  version: '1.0.0'
};
