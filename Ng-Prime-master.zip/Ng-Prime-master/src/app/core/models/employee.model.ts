export class Employee {
    Id: number;
    Name: string;
    Department: string;
    DepartmentId: number;
    Address: string;
    Age: number;
}