export class Department{
    Id : number;
    Name : string;
    Description: string;
}