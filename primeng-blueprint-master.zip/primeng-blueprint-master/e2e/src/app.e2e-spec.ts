import { AppPage } from './app.po';

describe('example-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });
});
