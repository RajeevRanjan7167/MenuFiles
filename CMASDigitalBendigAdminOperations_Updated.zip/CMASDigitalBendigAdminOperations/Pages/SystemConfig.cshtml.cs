using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CMASDigitalBendigAdminOperations.Services;

namespace CMASDigitalBendigAdminOperations.Pages
{
    /// <summary>
    /// Page 2: shows the System Name dropdown and the data grid. The grid loads
    /// all records on first load, then re-queries (via the OnGetRecords AJAX
    /// handler) whenever the System Name selection changes, so the whole page
    /// doesn't need to reload for filtering, sorting, or paging.
    /// </summary>
    public class SystemConfigModel : PageModel
    {
        private readonly IDatabaseConnectionService _dbConnectionService;
        private readonly ISystemDataService _systemDataService;
        private readonly ISessionConnectionAccessor _sessionAccessor;
        private readonly ILogger<SystemConfigModel> _logger;

        public SystemConfigModel(
            IDatabaseConnectionService dbConnectionService,
            ISystemDataService systemDataService,
            ISessionConnectionAccessor sessionAccessor,
            ILogger<SystemConfigModel> logger)
        {
            _dbConnectionService = dbConnectionService;
            _systemDataService = systemDataService;
            _sessionAccessor = sessionAccessor;
            _logger = logger;
        }

        public List<string> SystemNames { get; set; } = new();
        public string? SelectedDbDisplayName { get; set; }
        public string? ErrorMessage { get; set; }

        /// <summary>
        /// Loads the System Name dropdown on initial page load. The grid itself is
        /// populated client-side via an AJAX call to OnGetRecords once the page loads
        /// (see the Scripts section in SystemConfig.cshtml), so it always goes through
        /// the same code path used for filtering.
        /// </summary>
        public async Task<IActionResult> OnGetAsync()
        {
            var connectionKey = _sessionAccessor.GetSelectedConnectionKey();
            if (string.IsNullOrEmpty(connectionKey))
            {
                // No database chosen yet (e.g. direct navigation, expired session) -
                // send the user back to Page 1 rather than failing on a null connection.
                return RedirectToPage("/Index");
            }

            var option = _dbConnectionService.FindByKey(connectionKey);
            SelectedDbDisplayName = option?.DisplayName;

            try
            {
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);
                SystemNames = await _systemDataService.GetSystemNamesAsync(connectionString);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Failed to load system names for connection {Key}.", connectionKey);
                ErrorMessage = ex.Message;
            }

            return Page();
        }

        /// <summary>
        /// AJAX handler: GET /SystemConfig?handler=Records&amp;systemName=...
        /// Returns grid data (columns + rows) as JSON, optionally filtered by System Name.
        /// </summary>
        public async Task<IActionResult> OnGetRecordsAsync(string? systemName)
        {
            var connectionKey = _sessionAccessor.GetSelectedConnectionKey();
            if (string.IsNullOrEmpty(connectionKey))
            {
                return new JsonResult(new { error = "No database connection selected. Please start over." })
                {
                    StatusCode = StatusCodes.Status400BadRequest
                };
            }

            try
            {
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);
                var result = await _systemDataService.GetRecordsAsync(connectionString, systemName);

                return new JsonResult(new { columns = result.Columns, rows = result.Rows });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Failed to load records for connection {Key}, system {System}.", connectionKey, systemName);
                return new JsonResult(new { error = ex.Message })
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
        }
        public async Task<IActionResult> OnPostUpdateRecordAsync([FromBody] Dictionary<string, object?> record)
        {
            var connectionKey = _sessionAccessor.GetSelectedConnectionKey();
            if (string.IsNullOrEmpty(connectionKey))
                return new JsonResult(new { error = "No database connection selected. Please start over." }) { StatusCode = 400 };

            try
            {
                var connectionString = _dbConnectionService.GetConnectionString(connectionKey);
                var updated = await _systemDataService.UpdateRecordAsync(connectionString, record);
                return new JsonResult(new { success = true, message = "Record updated successfully.", record = updated });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Failed to update system configuration record.");
                return new JsonResult(new { error = ex.Message }) { StatusCode = 400 };
            }
        }

    }
}
