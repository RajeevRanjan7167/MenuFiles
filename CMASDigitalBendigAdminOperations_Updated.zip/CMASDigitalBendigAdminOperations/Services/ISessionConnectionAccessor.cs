namespace CMASDigitalBendigAdminOperations.Services
{
    /// <summary>
    /// Wraps reading/writing the selected database connection key to/from the
    /// user's session, so pages/handlers don't touch HttpContext.Session directly.
    /// </summary>
    public interface ISessionConnectionAccessor
    {
        string? GetSelectedConnectionKey();
        void SetSelectedConnectionKey(string key);
        void Clear();
    }
}
