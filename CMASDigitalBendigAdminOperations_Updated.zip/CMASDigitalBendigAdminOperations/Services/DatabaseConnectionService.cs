using Microsoft.Data.SqlClient;
using CMASDigitalBendigAdminOperations.Models;

namespace CMASDigitalBendigAdminOperations.Services
{
    /// <summary>
    /// Reads the list of configurable database connections from appsettings.json
    /// ("AvailableConnections" section) and provides validation/lookup helpers.
    ///
    /// Registered as a Scoped (or Singleton, since the list is static config)
    /// service in Program.cs.
    /// </summary>
    public class DatabaseConnectionService : IDatabaseConnectionService
    {
        private readonly List<DatabaseConnectionOption> _connections;
        private readonly ILogger<DatabaseConnectionService> _logger;

        public DatabaseConnectionService(IConfiguration configuration, ILogger<DatabaseConnectionService> logger)
        {
            _logger = logger;

            _connections = configuration
                .GetSection("AvailableConnections")
                .Get<List<DatabaseConnectionOption>>() ?? new List<DatabaseConnectionOption>();

            if (_connections.Count == 0)
            {
                _logger.LogWarning("No database connections were found under 'AvailableConnections' in configuration.");
            }
        }

        public IReadOnlyList<DatabaseConnectionOption> GetAvailableConnections() => _connections;

        public DatabaseConnectionOption? FindByKey(string key) =>
            _connections.FirstOrDefault(c => c.Key.Equals(key, StringComparison.OrdinalIgnoreCase));

        public string GetConnectionString(string key)
        {
            var option = FindByKey(key)
                ?? throw new InvalidOperationException($"No database connection configured with key '{key}'.");

            return option.ConnectionString;
        }

        public async Task ValidateConnectionAsync(string key)
        {
            var connectionString = GetConnectionString(key);

            // The demo connection is intentionally in-memory and always available.
            if (connectionString.Equals("DummyDatabase", StringComparison.OrdinalIgnoreCase))
            {
                await Task.CompletedTask;
                return;
            }

            try
            {
                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to open database connection for key '{Key}'.", key);
                throw new InvalidOperationException(
                    $"Could not connect to the database '{key}'. Please check the connection settings or try again.", ex);
            }
        }
    }
}
