using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using CMASDigitalBendigAdminOperations.Models;

namespace CMASDigitalBendigAdminOperations.Services
{
    /// <summary>
    /// Data-access service for Page 2 (System Configuration).
    ///
    /// Uses plain ADO.NET (SqlConnection/SqlCommand) rather than EF Core because the
    /// exact table schema is expected to vary by deployment/requirement doc - ADO.NET
    /// with a column-agnostic reader lets the grid adapt to whatever columns exist in
    /// "SystemDataSettings:TableName" without needing a matching EF entity/migration.
    ///
    /// If you prefer EF Core (e.g. because the schema is fixed and known up front),
    /// replace this implementation with a DbContext-based one that implements the
    /// same ISystemDataService interface - no other code needs to change.
    /// </summary>
    public class SystemDataService : ISystemDataService
    {
        private readonly SystemDataSettings _settings;
        private readonly ILogger<SystemDataService> _logger;
        private static readonly object DummyLock = new();
        private static readonly List<Dictionary<string, object?>> DummyRows = DummySystemData.CreateRows();

        private static readonly List<string> DummySystemNames = new()
        {
            "CUST1_UK", "CUST10_UK", "CUST11_UK", "CUST2_UK", "CUST3_UK", "CUST4_UK",
            "CUST6_UK", "CUST7_UK", "CUST9_UK", "MXCUSTOMS 10A", "MXCUSTOMS 1A",
            "MXCUSTOMS 5A", "MXCUSTOMS 5B", "MXCUSTOMS 6A", "MXCUSTOMS 6B",
            "MXCUSTOMS 7A", "MXCUSTOMS 7B", "MXCUSTOMS 8A", "MXCUSTOMS 8B",
            "MXCUSTOMS 9A", "MXCUSTOMS 9B", "MXWOODS5"
        };

        public SystemDataService(IOptions<SystemDataSettings> settings, ILogger<SystemDataService> logger)
        {
            _settings = settings.Value;
            _logger = logger;
        }

        public async Task<List<string>> GetSystemNamesAsync(string connectionString)
        {
            var results = new List<string>();

            if (connectionString.Equals("DummyDatabase", StringComparison.OrdinalIgnoreCase))
            {
                return await Task.FromResult(new List<string>(DummySystemNames));
            }

            // NOTE: TableName/SystemNameColumn come from configuration, not user input,
            // so string-building the identifiers here is safe (they're never
            // user-supplied at request time). Values are still passed as parameters.
            var sql = $"SELECT DISTINCT [{_settings.SystemNameColumn}] " +
                      $"FROM {_settings.TableName} " +
                      $"WHERE [{_settings.SystemNameColumn}] IS NOT NULL " +
                      $"ORDER BY [{_settings.SystemNameColumn}]";

            try
            {
                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                await using var command = new SqlCommand(sql, connection);
                await using var reader = await command.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    if (!reader.IsDBNull(0))
                    {
                        results.Add(reader.GetString(0));
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load system names from {Table}.", _settings.TableName);
                throw new InvalidOperationException("Unable to load System Names from the database.", ex);
            }

            return results;
        }

        public async Task<GridResult> GetRecordsAsync(string connectionString, string? systemName)
        {
            var result = new GridResult();

            if (connectionString.Equals("DummyDatabase", StringComparison.OrdinalIgnoreCase))
            {
                result.Columns.AddRange(new[] { "Line", "Operation_Id", "TagName", "TagValue", "Employee_ID", "Date_Inserted" });
                lock (DummyLock)
                {
                    foreach (var item in DummyRows.Where(x => string.IsNullOrWhiteSpace(systemName) ||
                        string.Equals(Convert.ToString(x["Line"]), systemName, StringComparison.OrdinalIgnoreCase)))
                    {
                        result.Rows.Add(new Dictionary<string, object?>(item));
                    }
                }
                return await Task.FromResult(result);
            }

            var sql = $"SELECT * FROM {_settings.TableName}";
            var hasFilter = !string.IsNullOrWhiteSpace(systemName);
            if (hasFilter)
            {
                sql += $" WHERE [{_settings.SystemNameColumn}] = @SystemName";
            }
            sql += $" ORDER BY [{_settings.SystemNameColumn}]";

            try
            {
                await using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                await using var command = new SqlCommand(sql, connection);
                if (hasFilter)
                {
                    // Parameterized -> safe from SQL injection even though the value
                    // originates from a user-controlled dropdown selection.
                    command.Parameters.AddWithValue("@SystemName", systemName);
                }

                await using var reader = await command.ExecuteReaderAsync();

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    result.Columns.Add(reader.GetName(i));
                }

                while (await reader.ReadAsync())
                {
                    var row = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    result.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load records from {Table} (filter: {Filter}).", _settings.TableName, systemName ?? "(none)");
                throw new InvalidOperationException("Unable to load records from the database.", ex);
            }

            return result;
        }
        public Task<Dictionary<string, object?>> UpdateRecordAsync(string connectionString, Dictionary<string, object?> record)
        {
            if (!connectionString.Equals("DummyDatabase", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Record updates are temporarily enabled only for the dummy database connection.");

            string Original(string key) => Convert.ToString(record.TryGetValue("__Original" + key, out var value) ? value : null) ?? string.Empty;

            lock (DummyLock)
            {
                var existing = DummyRows.FirstOrDefault(x =>
                    string.Equals(Convert.ToString(x["Line"]), Original("Line"), StringComparison.Ordinal) &&
                    string.Equals(Convert.ToString(x["Operation_Id"]), Original("Operation_Id"), StringComparison.Ordinal) &&
                    string.Equals(Convert.ToString(x["TagName"]), Original("TagName"), StringComparison.Ordinal) &&
                    string.Equals(Convert.ToString(x["Date_Inserted"]), Original("Date_Inserted"), StringComparison.Ordinal));

                if (existing == null)
                    throw new InvalidOperationException("The selected dummy record was not found.");

                foreach (var key in new[] { "Line", "Operation_Id", "TagName", "TagValue", "Employee_ID", "Date_Inserted" })
                {
                    if (record.TryGetValue(key, out var value))
                        existing[key] = Convert.ToString(value) ?? string.Empty;
                }

                return Task.FromResult(new Dictionary<string, object?>(existing));
            }
        }

    }
}
