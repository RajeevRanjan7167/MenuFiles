using CMASDigitalBendigAdminOperations.Models;

namespace CMASDigitalBendigAdminOperations.Services
{
    /// <summary>
    /// Manages the set of configurable database connections and the user's
    /// currently selected connection (persisted in session).
    /// </summary>
    public interface IDatabaseConnectionService
    {
        /// <summary>Returns all connections configured in appsettings.json.</summary>
        IReadOnlyList<DatabaseConnectionOption> GetAvailableConnections();

        /// <summary>
        /// Validates that the given key exists and that a connection can actually
        /// be opened against it. Throws InvalidOperationException on failure.
        /// </summary>
        Task ValidateConnectionAsync(string key);

        /// <summary>Looks up the raw connection string for a given key.</summary>
        string GetConnectionString(string key);

        /// <summary>Finds the option (for display) by key, or null if not found.</summary>
        DatabaseConnectionOption? FindByKey(string key);
    }
}
