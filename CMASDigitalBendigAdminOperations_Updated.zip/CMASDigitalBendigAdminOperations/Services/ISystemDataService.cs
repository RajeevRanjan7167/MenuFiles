using CMASDigitalBendigAdminOperations.Models;

namespace CMASDigitalBendigAdminOperations.Services
{
    public interface ISystemDataService
    {
        Task<List<string>> GetSystemNamesAsync(string connectionString);
        Task<GridResult> GetRecordsAsync(string connectionString, string? systemName);
        Task<Dictionary<string, object?>> UpdateRecordAsync(string connectionString, Dictionary<string, object?> record);
    }
}
