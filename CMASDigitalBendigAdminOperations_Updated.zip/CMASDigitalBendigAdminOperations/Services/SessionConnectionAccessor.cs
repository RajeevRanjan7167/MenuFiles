namespace CMASDigitalBendigAdminOperations.Services
{
    public class SessionConnectionAccessor : ISessionConnectionAccessor
    {
        private const string SessionKey = "SelectedDbConnectionKey";
        private readonly IHttpContextAccessor _httpContextAccessor;

        public SessionConnectionAccessor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        private HttpContext HttpContext =>
            _httpContextAccessor.HttpContext
            ?? throw new InvalidOperationException("No active HttpContext is available.");

        public string? GetSelectedConnectionKey() =>
            HttpContext.Session.GetString(SessionKey);

        public void SetSelectedConnectionKey(string key) =>
            HttpContext.Session.SetString(SessionKey, key);

        public void Clear() =>
            HttpContext.Session.Remove(SessionKey);
    }
}
