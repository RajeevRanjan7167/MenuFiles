# Manufacturing System Configuration — Razor Pages App

ASP.NET Core (.NET 8) Razor Pages application implementing:

- **Page 1 (`/Index`)** — dropdown of configurable database connections → validates
  the connection → stores the choice in session → redirects to Page 2.
- **Page 2 (`/SystemConfig`)** — System Name dropdown + a data grid (DataTables.js,
  client-side sort/paging) that loads all records on page load and re-filters via
  AJAX whenever the dropdown changes.

> **Note on the data grid columns:** No requirement-doc screenshot was attached to
> the original request, so the grid is built to be **schema-flexible** rather than
> hard-coded to a fixed set of columns. `SystemDataService` runs `SELECT * FROM
> <table>` and the grid renders whatever columns come back — including `UserId`,
> `Timestamp`, `MeasuredLoft`, `MeasuredLie`, and any additional fields your table
> has. Once you share the actual requirement doc, the table/column names in
> `appsettings.json` (`SystemDataSettings`) can be pointed at the real schema, or
> `SystemDataService.GetRecordsAsync` can be tightened to `SELECT` an explicit,
> ordered column list if you want fixed grid headers/order.

## Project structure

```
CMASDigitalBendigAdminOperations/
├── Program.cs                          # DI, session, middleware pipeline
├── appsettings.json                    # Configurable DB connections + table/column names
├── Models/
│   ├── DatabaseConnectionOption.cs     # One entry in the Page 1 dropdown
│   ├── SystemDataSettings.cs           # Bound from "SystemDataSettings" config section
│   └── GridResult.cs                   # Columns + rows returned to the grid
├── Services/
│   ├── IDatabaseConnectionService.cs / DatabaseConnectionService.cs
│   │        # Reads AvailableConnections from config, validates/opens connections
│   ├── ISystemDataService.cs / SystemDataService.cs
│   │        # ADO.NET queries for System Names + grid records (schema-flexible)
│   └── ISessionConnectionAccessor.cs / SessionConnectionAccessor.cs
│            # Wraps session get/set of the selected connection key
├── Pages/
│   ├── Index.cshtml(.cs)               # Page 1
│   ├── SystemConfig.cshtml(.cs)        # Page 2
│   ├── Error.cshtml(.cs)
│   └── Shared/_Layout.cshtml           # Bootstrap 5 layout
└── wwwroot/css/site.css
```

## Configuring database connections

Edit `appsettings.json`:

```json
"AvailableConnections": [
  {
    "Key": "PLANT1_PROD",
    "DisplayName": "Plant 1 - Production DB",
    "ConnectionString": "Server=...;Database=...;..."
  }
]
```

- `Key` is the internal identifier stored in session.
- `DisplayName` is what shows up in the Page 1 dropdown.
- Add/remove entries here to change what users can select — no code changes needed.

**Security note:** the sample includes a plaintext password for illustration only.
In a real deployment, keep secrets out of `appsettings.json` — use
[.NET User Secrets](https://learn.microsoft.com/aspnet/core/security/app-secrets)
locally, or environment variables / Azure Key Vault / AWS Secrets Manager in
production, and reference them via `IConfiguration` the same way.

## Pointing the grid at your real table

Edit the `SystemDataSettings` section:

```json
"SystemDataSettings": {
  "TableName": "dbo.SystemRecords",
  "SystemNameColumn": "SystemName"
}
```

- `TableName` — the table/view the grid queries.
- `SystemNameColumn` — the column used both for the dropdown's distinct values and
  for filtering the grid.

If your real table lives behind a more complex query (joins, computed columns,
etc.), replace the `SELECT * FROM {TableName}` in
`SystemDataService.GetRecordsAsync` with your actual query — the rest of the
pipeline (JSON serialization, dynamic grid rendering) does not need to change.

## Running locally

```bash
dotnet restore
dotnet run
```

Then browse to the URL shown in the console (e.g. `https://localhost:5001`).

## Extending

- **EF Core instead of ADO.NET:** once your schema is fixed and known, you can
  swap `SystemDataService` for an EF Core–based implementation (add a `DbContext`
  configured with the connection string resolved per-session, add an entity
  matching your table) — since it implements `ISystemDataService`, no other code
  needs to change.
- **Multiple DB engines:** `Microsoft.Data.SqlClient` targets SQL Server. If some
  connections point at other engines (PostgreSQL, MySQL, etc.), add the relevant
  provider package and branch on a `Provider` field added to
  `DatabaseConnectionOption`.
- **Authentication/authorization:** not included here since it wasn't specified;
  add ASP.NET Core Identity or your organization's auth scheme and apply
  `[Authorize]` to the pages as needed.

## Latest updates
- Fixed System Name filtering for dummy data by filtering the `Line` field used by the grid records.
- Renamed the project/namespace to `CMASDigitalBendigAdminOperations`.
- Data grid default page size is 10 records, with selectable sizes 10, 25, and 50 (maximum 50).
