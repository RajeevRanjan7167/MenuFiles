using CMASDigitalBendigAdminOperations.Models;
using CMASDigitalBendigAdminOperations.Services;

var builder = WebApplication.CreateBuilder(args);

// ---- MVC / Razor Pages ----
builder.Services.AddRazorPages(options =>
{
    // Page 2 requires that a database has been selected on Page 1 first.
    // (Enforced in SystemConfig.cshtml.cs via a redirect, kept simple here.)
});

// ---- Strongly-typed configuration binding ----
builder.Services.Configure<SystemDataSettings>(
    builder.Configuration.GetSection("SystemDataSettings"));

// ---- Session support (used to persist the selected DB connection) ----
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddHttpContextAccessor();

// ---- Application services (DI) ----
builder.Services.AddSingleton<IDatabaseConnectionService, DatabaseConnectionService>();
builder.Services.AddScoped<ISystemDataService, SystemDataService>();
builder.Services.AddScoped<ISessionConnectionAccessor, SessionConnectionAccessor>();

var app = builder.Build();

// ---- Middleware pipeline ----
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

app.MapRazorPages();

app.Run();
