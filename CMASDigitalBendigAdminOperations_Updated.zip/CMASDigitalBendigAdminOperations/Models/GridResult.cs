namespace CMASDigitalBendigAdminOperations.Models
{
    /// <summary>
    /// Generic, schema-flexible result for populating the data grid on Page 2.
    /// Using a column list + row dictionaries (rather than a fixed POCO) means the
    /// grid automatically adapts if fields are added/renamed in the source table,
    /// without requiring a code change here.
    ///
    /// Known/expected columns (per the requirement doc) include:
    ///   UserId, Timestamp, MeasuredLoft, MeasuredLie, SystemName
    /// plus any additional columns present in the configured table.
    /// </summary>
    public class GridResult
    {
        /// <summary>Ordered list of column names, as returned by the query.</summary>
        public List<string> Columns { get; set; } = new();

        /// <summary>Each row is a column-name -> value dictionary.</summary>
        public List<Dictionary<string, object?>> Rows { get; set; } = new();
    }
}
