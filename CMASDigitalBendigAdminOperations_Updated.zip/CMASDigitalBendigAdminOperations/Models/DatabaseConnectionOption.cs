namespace CMASDigitalBendigAdminOperations.Models
{
    /// <summary>
    /// Represents a single selectable database connection, as configured in
    /// appsettings.json under the "AvailableConnections" section.
    /// </summary>
    public class DatabaseConnectionOption
    {
        /// <summary>
        /// Unique, stable identifier for this connection (used as the value stored
        /// in session and as the dropdown's option value). Not shown to the user.
        /// </summary>
        public string Key { get; set; } = string.Empty;

        /// <summary>
        /// Friendly, human-readable name shown in the dropdown list.
        /// </summary>
        public string DisplayName { get; set; } = string.Empty;

        /// <summary>
        /// The actual ADO.NET connection string. Kept out of view once a connection
        /// is selected - only the Key is persisted in session, and the connection
        /// string is re-resolved server-side from configuration on each request.
        /// </summary>
        public string ConnectionString { get; set; } = string.Empty;
    }
}
