namespace CMASDigitalBendigAdminOperations.Models
{
    /// <summary>
    /// Strongly-typed binding for the "SystemDataSettings" configuration section.
    /// Lets you repoint the grid at a different table/column without touching code.
    /// </summary>
    public class SystemDataSettings
    {
        public string TableName { get; set; } = "dbo.SystemRecords";
        public string SystemNameColumn { get; set; } = "SystemName";
    }
}
